add_search_path . /usr/local/apps/cadence/DDI/DDI251/GENUS251/tools.lnx86/lib/tech -library -both
read_library -liberty -both \
    /nfs/guille/johnston/ece499/pnr/sky130_scl_9T_0.0.5a/sky130_scl_9T_0.0.5/lib/sky130_ss_1.62_125_nldm.lib

