`timescale 1ns/1ps

module tb_p2s_16bit;

    reg         clk;
    reg         reset;
    reg         load;
    reg         shift_en;
    reg  [15:0] data_in;
    wire        out;

    integer i;

    p2s_16bit uut (
        .clk(clk),
        .reset(reset),
        .load(load),
        .shift_en(shift_en),
        .data_in(data_in),
        .out(out)
    );

    // 10ns clock period
    always #5 clk = ~clk;

    initial begin
        clk      = 1'b0;
        reset    = 1'b1;
        load     = 1'b0;
        shift_en = 1'b0;
        data_in  = 16'b0;

        // Reset
        #12;
        reset = 1'b0;

        // Load data
        data_in = 16'b1011001101010101;
        load = 1'b1;
        #10;
        load = 1'b0;

        $display("Expected serial output:");
        $display("1 0 1 1 0 0 1 1 0 1 0 1 0 1 0 1");

        $write("Actual serial output:   ");
        $write("%b ", out);

        shift_en = 1'b1;

        // Already displayed first MSB, so shift/display remaining 15 bits
        for (i = 0; i < 15; i = i + 1) begin
            #10;
            $write("%b ", out);
        end

        $display("");
        shift_en = 1'b0;

        #10;
        $finish;
    end

endmodule
