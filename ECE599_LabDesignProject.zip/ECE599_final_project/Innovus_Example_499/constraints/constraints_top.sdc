create_clock -name clk -period 10 -waveform {0 5} [get_ports "clk"]

set_clock_transition 0.2 [get_clocks "clk"]
set_clock_uncertainty 0.15 [get_clocks "clk"]

set_input_delay -max 2.0 [get_ports "reset"] -clock [get_clocks "clk"]
set_input_delay -max 2.0 [get_ports "start"] -clock [get_clocks "clk"]
set_input_delay -max 2.0 [get_ports "in"]    -clock [get_clocks "clk"]

set_output_delay -max 4.0 [get_ports "out"]  -clock [get_clocks "clk"]
set_output_delay -max 4.0 [get_ports "done"] -clock [get_clocks "clk"]
