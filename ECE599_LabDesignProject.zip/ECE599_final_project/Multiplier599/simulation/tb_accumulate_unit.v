`timescale 1ns/1ps

module tb_accumulate_unit;

    reg         clk;
    reg         reset;
    reg         clear_acc;
    reg         load_acc;
    reg  [7:0]  mult_out;
    reg  [1:0]  shift_sel;
    wire [15:0] acc_out;

    accumulate_unit uut (
        .clk(clk),
        .reset(reset),
        .clear_acc(clear_acc),
        .load_acc(load_acc),
        .mult_out(mult_out),
        .shift_sel(shift_sel),
        .acc_out(acc_out)
    );

    // 10ns clock
    always #5 clk = ~clk;

    initial begin
        clk       = 1'b0;
        reset     = 1'b1;
        clear_acc = 1'b0;
        load_acc  = 1'b0;
        mult_out  = 8'b0;
        shift_sel = 2'b00;

        // reset
        #12;
        reset = 1'b0;

        // clear accumulator
        clear_acc = 1'b1;
        #10;
        clear_acc = 1'b0;

        // 1) add 0x0F << 0  => 0x000F
        mult_out  = 8'h0F;
        shift_sel = 2'b00;
        load_acc  = 1'b1;
        #10;
        load_acc  = 1'b0;
        #1;
        $display("acc_out = %h (expected 000F)", acc_out);

        // 2) add 0x03 << 4  => 0x0030, total = 0x003F
        #9;
        mult_out  = 8'h03;
        shift_sel = 2'b01;
        load_acc  = 1'b1;
        #10;
        load_acc  = 1'b0;
        #1;
        $display("acc_out = %h (expected 003F)", acc_out);

        // 3) add 0x02 << 8  => 0x0200, total = 0x023F
        #9;
        mult_out  = 8'h02;
        shift_sel = 2'b10;
        load_acc  = 1'b1;
        #10;
        load_acc  = 1'b0;
        #1;
        $display("acc_out = %h (expected 023F)", acc_out);

        if (acc_out == 16'h023F)
            $display("PASS: accumulate_unit works correctly.");
        else
            $display("FAIL: accumulate_unit output mismatch.");

        #10;
        $finish;
    end

endmodule
