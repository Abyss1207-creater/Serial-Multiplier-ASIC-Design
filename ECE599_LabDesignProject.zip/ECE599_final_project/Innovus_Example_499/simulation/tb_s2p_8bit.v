`timescale 1ns/1ps

module tb_s2p_8bit;

    reg        clk;
    reg        reset;
    reg        shift_en;
    reg        in;
    wire [3:0] A;
    wire [3:0] B;

    s2p_8bit uut (
        .clk(clk),
        .reset(reset),
        .shift_en(shift_en),
        .in(in),
        .A(A),
        .B(B)
    );

    // 10ns clock period
    always #5 clk = ~clk;

    initial begin
        clk      = 1'b0;
        reset    = 1'b1;
        shift_en = 1'b0;
        in       = 1'b0;

        // Reset
        #12;
        reset    = 1'b0;
        shift_en = 1'b1;

        // Shift in: 1011_0101
        // Expect A = 1011, B = 0101
        in = 1'b1; #10;
        in = 1'b0; #10;
        in = 1'b1; #10;
        in = 1'b1; #10;
        in = 1'b0; #10;
        in = 1'b1; #10;
        in = 1'b0; #10;
        in = 1'b1; #10;

        shift_en = 1'b0;
        #10;

        $display("A = %b (expected 1011)", A);
        $display("B = %b (expected 0101)", B);

        if (A == 4'b1011 && B == 4'b0101)
            $display("PASS: S2P works correctly.");
        else
            $display("FAIL: S2P output mismatch.");

        #10;
        $finish;
    end

endmodule
