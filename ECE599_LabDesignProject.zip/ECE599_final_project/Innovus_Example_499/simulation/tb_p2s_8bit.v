`timescale 1ns/1ps

module tb_p2s_8bit;

    reg clk;
    reg reset;
    reg load;
    reg shift_en;
    reg [7:0] data_in;
    wire out;

    p2s_8bit uut (
        .clk(clk),
        .reset(reset),
        .load(load),
        .shift_en(shift_en),
        .data_in(data_in),
        .out(out)
    );

    always #5 clk = ~clk;

    initial begin
        clk = 0;
        reset = 1;
        load = 0;
        shift_en = 0;
        data_in = 8'b0;

        #12;
        reset = 0;

        // Load data = 10110101
        data_in = 8'b10110101;
        load = 1;
        #10;
        load = 0;

        // First bit should already be visible at out
        $display("Expected serial output: 1 0 1 1 0 1 0 1");
        $write("Actual serial output:   ");
        $write("%b ", out);

        shift_en = 1;

        repeat(7) begin
            #10;
            $write("%b ", out);
        end

        $display("");
        #10;
        $finish;
    end

endmodule
