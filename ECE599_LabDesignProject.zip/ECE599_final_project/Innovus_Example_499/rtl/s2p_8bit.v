`timescale 1ns/1ps

module s2p_8bit (
    input        clk,
    input        reset,
    input        shift_en,
    input        in,
    output [3:0] A,
    output [3:0] B
);

    reg [7:0] shift_reg;

    always @(posedge clk or posedge reset) begin
        if (reset)
            shift_reg <= 8'b00000000;
        else if (shift_en)
            shift_reg <= {shift_reg[6:0], in};
    end

    assign A = shift_reg[7:4];
    assign B = shift_reg[3:0];

endmodule
