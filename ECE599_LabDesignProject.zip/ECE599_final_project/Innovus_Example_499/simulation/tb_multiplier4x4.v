`timescale 1ns/1ps

module tb_multiplier4x4;

reg  [3:0] A;
reg  [3:0] B;
wire [7:0] P;

// Instantiate the multiplier
multiplier4x4 uut (
    .A(A),
    .B(B),
    .P(P)
);

initial begin

    $display("A  B  |  P (Expected)");
    $display("---------------------");

    A = 4'd3;  B = 4'd5;  #10;
    $display("%d  %d  |  %d (15)", A, B, P);

    A = 4'd7;  B = 4'd9;  #10;
    $display("%d  %d  |  %d (63)", A, B, P);

    A = 4'd15; B = 4'd15; #10;
    $display("%d  %d  |  %d (225)", A, B, P);

    A = 4'd4;  B = 4'd6;  #10;
    $display("%d  %d  |  %d (24)", A, B, P);

    A = 4'd0;  B = 4'd12; #10;
    $display("%d  %d  |  %d (0)", A, B, P);

    A = 4'd10; B = 4'd3;  #10;
    $display("%d  %d  |  %d (30)", A, B, P);

    $display("---------------------");
    $display("Simulation finished.");

    $finish;

end

endmodule
