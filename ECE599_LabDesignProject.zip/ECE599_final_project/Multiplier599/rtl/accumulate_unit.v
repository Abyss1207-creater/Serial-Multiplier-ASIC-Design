`timescale 1ns/1ps

module accumulate_unit (
    input         clk,
    input         reset,
    input         clear_acc,
    input         load_acc,
    input  [7:0]  mult_out,
    input  [1:0]  shift_sel,   // 00: <<0, 01: <<4, 10: <<8
    output [15:0] acc_out
);

    reg  [15:0] acc_reg;
    reg  [15:0] shifted_pp;
    wire [15:0] add_result;

    // Shift / align the 8-bit multiplier output into 16-bit space
    always @(*) begin
        case (shift_sel)
            2'b00: shifted_pp = {8'b0, mult_out};          // << 0
            2'b01: shifted_pp = {4'b0, mult_out, 4'b0};   // << 4
            2'b10: shifted_pp = {mult_out, 8'b0};         // << 8
            default: shifted_pp = {8'b0, mult_out};
        endcase
    end

    // 16-bit add
    assign add_result = acc_reg + shifted_pp;

    // Accumulator register
    always @(posedge clk or posedge reset) begin
        if (reset)
            acc_reg <= 16'b0;
        else if (clear_acc)
            acc_reg <= 16'b0;
        else if (load_acc)
            acc_reg <= add_result;
    end

    assign acc_out = acc_reg;

endmodule
