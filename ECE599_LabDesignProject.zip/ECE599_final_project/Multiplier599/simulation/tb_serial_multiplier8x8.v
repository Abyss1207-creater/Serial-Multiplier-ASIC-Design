`timescale 1ns/1ps

module tb_serial_multiplier8x8;

    reg clk;
    reg reset;
    reg start;
    reg in;

    wire out;
    wire done;

    reg [15:0] out_capture;
    integer i;

    serial_multiplier8x8_top uut (
        .clk(clk),
        .reset(reset),
        .start(start),
        .in(in),
        .out(out),
        .done(done)
    );

    // 10 ns clock period
    always #5 clk = ~clk;

    // Drive reset, start, and serial input
    initial begin
        clk = 1'b0;
        reset = 1'b1;
        start = 1'b0;
        in = 1'b0;
        out_capture = 16'b0;

        // Reset
        #12;
        reset = 1'b0;

        // Start pulse
        #8;
        start = 1'b1;
        #10;
        start = 1'b0;

        // Send A = 00001101 (13), MSB first
        in = 1'b0; #10;  // A7
        in = 1'b0; #10;  // A6
        in = 1'b0; #10;  // A5
        in = 1'b0; #10;  // A4
        in = 1'b1; #10;  // A3
        in = 1'b1; #10;  // A2
        in = 1'b0; #10;  // A1
        in = 1'b1; #10;  // A0

        // Send B = 00001001 (9), MSB first
        in = 1'b0; #10;  // B7
        in = 1'b0; #10;  // B6
        in = 1'b0; #10;  // B5
        in = 1'b0; #10;  // B4
        in = 1'b1; #10;  // B3
        in = 1'b0; #10;  // B2
        in = 1'b0; #10;  // B1
        in = 1'b1; #10;  // B0
    end

    // Capture serial output when SHIFT_OUT begins
    initial begin
        out_capture = 16'b0;

        wait(reset == 1'b0);
        wait(start == 1'b1);

        // Wait until the FSM enters the output shifting phase
        wait(uut.p2s_shift_en == 1'b1);

        // Small delay to allow out to settle
        #1;

        $display("Expected output = 0000000001110101");
        $write("Captured output = ");

        // Capture first output bit immediately
        out_capture[15] = out;
        $write("%b", out);

        // Capture remaining 15 bits on subsequent clock cycles
        for (i = 1; i < 16; i = i + 1) begin
            @(posedge clk);
            #1;
            out_capture[15-i] = out;
            $write("%b", out);
        end

        $display("");

        #1;
        if (out_capture == 16'b0000000001110101)
            $display("PASS: serial_multiplier8x8_top works correctly.");
        else begin
            $display("FAIL: output mismatch.");
            $display("Captured = %b", out_capture);
            $display("Expected = 0000000001110101");
        end

        wait(done == 1'b1);
        $display("done asserted at time %0t", $time);

        #10;
        $finish;
    end

endmodule
