# ####################################################################

#  Created by Genus(TM) Synthesis Solution 25.12-s067_1 on Wed Mar 18 22:28:44 PDT 2026

# ####################################################################

set sdc_version 2.0

set_units -capacitance 1000fF
set_units -time 1000ps

# Set the current design
current_design serial_multiplier_top

create_clock -name "clk" -period 10.0 -waveform {0.0 5.0} [get_ports clk]
set_clock_transition 0.2 [get_clocks clk]
set_clock_gating_check -setup 0.0 
set_input_delay -clock [get_clocks clk] -add_delay -max 2.0 [get_ports reset]
set_input_delay -clock [get_clocks clk] -add_delay -max 2.0 [get_ports start]
set_input_delay -clock [get_clocks clk] -add_delay -max 2.0 [get_ports in]
set_output_delay -clock [get_clocks clk] -add_delay -max 4.0 [get_ports out]
set_output_delay -clock [get_clocks clk] -add_delay -max 4.0 [get_ports done]
set_clock_uncertainty -setup 0.15 [get_clocks clk]
set_clock_uncertainty -hold 0.15 [get_clocks clk]
