`timescale 1ns/1ps

module serial_multiplier_top (
    input  clk,
    input  reset,
    input  start,
    input  in,
    output out,
    output done
);

    // datapath wires
    wire [3:0] A;
    wire [3:0] B;
    wire [7:0] S;

    // control wires
    wire s2p_shift_en;
    wire p2s_load;
    wire p2s_shift_en;

    // Serial ? Parallel
    s2p_8bit u_s2p (
        .clk(clk),
        .reset(reset),
        .shift_en(s2p_shift_en),
        .in(in),
        .A(A),
        .B(B)
    );

    // 4x4 multiplier
    multiplier4x4 u_mult (
        .A(A),
        .B(B),
        .P(S)
    );

    // Parallel ? Serial
    p2s_8bit u_p2s (
        .clk(clk),
        .reset(reset),
        .load(p2s_load),
        .shift_en(p2s_shift_en),
        .data_in(S),
        .out(out)
    );

    // Controller FSM
    controller_fsm u_fsm (
        .clk(clk),
        .reset(reset),
        .start(start),
        .s2p_shift_en(s2p_shift_en),
        .p2s_load(p2s_load),
        .p2s_shift_en(p2s_shift_en),
        .done(done)
    );

endmodule
