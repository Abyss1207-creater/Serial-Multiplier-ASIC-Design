`timescale 1ns/1ps

module p2s_8bit (
    input        clk,
    input        reset,
    input        load,
    input        shift_en,
    input  [7:0] data_in,
    output       out
);

    reg [7:0] shift_reg;

    always @(posedge clk or posedge reset) begin
        if (reset)
            shift_reg <= 8'b0;
        else if (load)
            shift_reg <= data_in;
        else if (shift_en)
            shift_reg <= {shift_reg[6:0], 1'b0};
    end

    assign out = shift_reg[7];

endmodule
