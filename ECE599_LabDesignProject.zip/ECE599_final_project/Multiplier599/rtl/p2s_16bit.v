`timescale 1ns/1ps

module p2s_16bit (
    input         clk,
    input         reset,
    input         load,
    input         shift_en,
    input  [15:0] data_in,
    output        out
);

    reg [15:0] shift_reg;

    always @(posedge clk or posedge reset) begin
        if (reset)
            shift_reg <= 16'b0;
        else if (load)
            shift_reg <= data_in;
        else if (shift_en)
            shift_reg <= {shift_reg[14:0], 1'b0};
    end

    assign out = shift_reg[15];

endmodule
