`timescale 1ns/1ps

module tb_controller_fsm;

reg clk;
reg reset;
reg start;

wire s2p_shift_en;
wire p2s_load;
wire p2s_shift_en;
wire done;

controller_fsm uut(
    .clk(clk),
    .reset(reset),
    .start(start),
    .s2p_shift_en(s2p_shift_en),
    .p2s_load(p2s_load),
    .p2s_shift_en(p2s_shift_en),
    .done(done)
);

// clock
always #5 clk = ~clk;

initial begin

clk = 0;
reset = 1;
start = 0;

#12
reset = 0;

// start signal
#10
start = 1;

#10
start = 0;

// let FSM run
#200

$finish;

end

endmodule
