# ####################################################################

#  Created by Genus(TM) Synthesis Solution 25.12-s067_1 on Tue Feb 24 16:08:06 PST 2026

# ####################################################################

set sdc_version 2.0

set_units -capacitance 1000fF
set_units -time 1000ps

# Set the current design
current_design counter_4b

create_clock -name "clk" -period 10.0 -waveform {0.0 5.0} [get_ports clk]
set_clock_transition 0.5 [get_clocks clk]
set_load -pin_load 0.1 [get_ports {count[3]}]
set_load -pin_load 0.1 [get_ports {count[2]}]
set_load -pin_load 0.1 [get_ports {count[1]}]
set_load -pin_load 0.1 [get_ports {count[0]}]
set_clock_gating_check -setup 0.0 
set_input_delay -clock [get_clocks clk] -add_delay -max 2.0 [get_ports rst]
set_output_delay -clock [get_clocks clk] -add_delay -max 4.0 [get_ports {count[3]}]
set_output_delay -clock [get_clocks clk] -add_delay -max 4.0 [get_ports {count[2]}]
set_output_delay -clock [get_clocks clk] -add_delay -max 4.0 [get_ports {count[1]}]
set_output_delay -clock [get_clocks clk] -add_delay -max 4.0 [get_ports {count[0]}]
set_clock_uncertainty -setup 0.15 [get_ports clk]
set_clock_uncertainty -hold 0.15 [get_ports clk]
