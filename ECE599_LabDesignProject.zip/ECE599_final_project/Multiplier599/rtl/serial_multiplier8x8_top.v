`timescale 1ns/1ps

module serial_multiplier8x8_top (
    input  clk,
    input  reset,
    input  start,
    input  in,
    output out,
    output done
);

    // ----------------------------
    // Internal datapath wires
    // ----------------------------
    wire [7:0] A;
    wire [7:0] B;

    wire [3:0] mult_a;
    wire [3:0] mult_b;
    wire [7:0] mult_out;

    wire [15:0] acc_out;

    // ----------------------------
    // Internal control wires
    // ----------------------------
    wire        s2p_shift_en;
    wire        clear_acc;
    wire        load_acc;
    wire        p2s_load;
    wire        p2s_shift_en;
    wire [1:0]  shift_sel;
    wire        a_sel;
    wire        b_sel;

    // ----------------------------
    // Serial-to-Parallel 16-bit
    // ----------------------------
    s2p_16bit u_s2p (
        .clk(clk),
        .reset(reset),
        .shift_en(s2p_shift_en),
        .in(in),
        .A(A),
        .B(B)
    );

    // ----------------------------
    // Nibble select
    // a_sel = 0 -> A_lo, 1 -> A_hi
    // b_sel = 0 -> B_lo, 1 -> B_hi
    // ----------------------------
    assign mult_a = (a_sel == 1'b0) ? A[3:0] : A[7:4];
    assign mult_b = (b_sel == 1'b0) ? B[3:0] : B[7:4];

    // ----------------------------
    // 4x4 multiplier
    // ----------------------------
    multiplier4x4 u_mult (
        .A(mult_a),
        .B(mult_b),
        .P(mult_out)
    );

    // ----------------------------
    // Accumulate unit
    // ----------------------------
    accumulate_unit u_acc (
        .clk(clk),
        .reset(reset),
        .clear_acc(clear_acc),
        .load_acc(load_acc),
        .mult_out(mult_out),
        .shift_sel(shift_sel),
        .acc_out(acc_out)
    );

    // ----------------------------
    // Parallel-to-Serial 16-bit
    // ----------------------------
    p2s_16bit u_p2s (
        .clk(clk),
        .reset(reset),
        .load(p2s_load),
        .shift_en(p2s_shift_en),
        .data_in(acc_out),
        .out(out)
    );

    // ----------------------------
    // FSM controller
    // ----------------------------
    controller_fsm_599 u_fsm (
        .clk(clk),
        .reset(reset),
        .start(start),
        .s2p_shift_en(s2p_shift_en),
        .clear_acc(clear_acc),
        .load_acc(load_acc),
        .p2s_load(p2s_load),
        .p2s_shift_en(p2s_shift_en),
        .done(done),
        .shift_sel(shift_sel),
        .a_sel(a_sel),
        .b_sel(b_sel)
    );

endmodule
