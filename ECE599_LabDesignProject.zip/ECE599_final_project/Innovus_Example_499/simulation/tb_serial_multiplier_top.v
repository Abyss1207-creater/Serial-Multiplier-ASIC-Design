`timescale 1ns/1ps

module tb_serial_multiplier_top;

    reg clk;
    reg reset;
    reg start;
    reg in;

    wire out;
    wire done;

    reg [7:0] out_capture;
    integer i;

    serial_multiplier_top uut (
        .clk(clk),
        .reset(reset),
        .start(start),
        .in(in),
        .out(out),
        .done(done)
    );

    // 10ns clock period
    always #5 clk = ~clk;

    initial begin
        clk = 0;
        reset = 1;
        start = 0;
        in = 0;
        out_capture = 8'b0;

        // Reset
        #12;
        reset = 0;

        // Start pulse
        #8;
        start = 1;
        #10;
        start = 0;

        // Send serial input: A=0011, B=0101
        // Order: A3 A2 A1 A0 B3 B2 B1 B0
        in = 0; #10;   // A3
        in = 0; #10;   // A2
        in = 1; #10;   // A1
        in = 1; #10;   // A0
        in = 0; #10;   // B3
        in = 1; #10;   // B2
        in = 0; #10;   // B1
        in = 1; #10;   // B0

        // Wait until output phase begins and capture 8 serial output bits
        wait(done == 1'b1);

        // For current FSM, done comes after shifting out.
        // So capture output during the shift-out interval by timing:
        // restart sim structure could be improved later, but here we simply
        // monitor expected window before done.

        // This display is for debug
        $display("done asserted at time %0t", $time);

        #20;
        $finish;
    end

    // Capture outgoing serial bits during shift_out window
    // Since output is MSB-first, shift bits into out_capture from left to right
    initial begin
        wait(reset == 0);
        wait(start == 1);

        // Wait through:
        // 8 input clocks + 1 load clock
        #(10*9);

        // Capture 8 output bits
        for (i = 0; i < 8; i = i + 1) begin
            #10;
            out_capture[7-i] = out;
        end

        #1;
        $display("Captured output = %b", out_capture);
        $display("Expected output = 00001111");

        if (out_capture == 8'b00001111)
            $display("PASS: Top-level serial multiplier works correctly.");
        else
            $display("FAIL: Top-level output mismatch.");
    end

endmodule
