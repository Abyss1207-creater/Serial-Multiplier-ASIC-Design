# Cadence Genus(TM) Synthesis Solution, Version 25.12-s067_1, built Nov 17 2025 13:10:10

# Date: Wed Mar 18 22:28:17 2026
# Host: eng-analogsim3.eecs.oregonstate.edu (x86_64 w/Linux 5.14.0-611.24.1.el9_7.x86_64) (32cores*128cpus*2physical cpus*INTEL(R) XEON(R) GOLD 6548N 61440KB)
# OS:   Rocky Linux 9.7 (Blue Onyx)

source genus_script.tcl
