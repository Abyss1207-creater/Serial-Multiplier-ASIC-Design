# MMMC View Definition File

create_library_set -name max_timing\
	-timing [list $env(SLOW_LIB)]
 
create_library_set -name min_timing\
	-timing [list $env(FAST_LIB)]

create_timing_condition -name default_mapping_tc_2\
   -library_sets min_timing
create_timing_condition -name default_mapping_tc_1\
   -library_sets max_timing

create_rc_corner -name rccorners\
	-cap_table [list $env(CAP_TABLE)]\
	-pre_route_res 1\
	-post_route_res 1\
	-pre_route_cap 1\
	-post_route_cap 1\
	-post_route_cross_cap 1\
	-pre_route_clock_res 0\
	-pre_route_clock_cap 0\

create_delay_corner -name max_delay\
   -timing_condition {default_mapping_tc_1}\
   -rc_corner rccorners
create_delay_corner -name min_delay\
   -timing_condition {default_mapping_tc_2}\
   -rc_corner rccorners

create_constraint_mode -name sdc_cons\
	-sdc_files [list $env(PROJECT_HOME)/synthesis/outputs/${my_toplevel}_sdc.sdc]

create_analysis_view -name wc -constraint_mode sdc_cons -delay_corner max_delay
create_analysis_view -name bc -constraint_mode sdc_cons -delay_corner min_delay

set_analysis_view -setup wc -hold bc
