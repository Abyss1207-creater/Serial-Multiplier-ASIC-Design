`timescale 1ns/1ps

module s2p_16bit (
    input        clk,
    input        reset,
    input        shift_en,
    input        in,
    output [7:0] A,
    output [7:0] B
);

    reg [15:0] shift_reg;

    always @(posedge clk or posedge reset) begin
        if (reset)
            shift_reg <= 16'b0;
        else if (shift_en)
            shift_reg <= {shift_reg[14:0], in};
    end

    assign A = shift_reg[15:8];
    assign B = shift_reg[7:0];

endmodule
