`timescale 1ns/1ps

module controller_fsm_599(

    input clk,
    input reset,
    input start,

    output reg s2p_shift_en,
    output reg clear_acc,
    output reg load_acc,
    output reg p2s_load,
    output reg p2s_shift_en,
    output reg done,

    output reg [1:0] shift_sel,
    output reg a_sel,
    output reg b_sel
);

    // FSM states
    localparam IDLE       = 4'd0;
    localparam LOAD_IN    = 4'd1;
    localparam CLEAR_ACC  = 4'd2;
    localparam MUL0_ACC   = 4'd3;
    localparam MUL1_ACC   = 4'd4;
    localparam MUL2_ACC   = 4'd5;
    localparam MUL3_ACC   = 4'd6;
    localparam LOAD_P2S   = 4'd7;
    localparam SHIFT_OUT  = 4'd8;
    localparam DONE_ST    = 4'd9;

    reg [3:0] state, next_state;
    reg [4:0] counter;

    //---------------------------------------
    // state register
    //---------------------------------------
    always @(posedge clk or posedge reset) begin
        if (reset)
            state <= IDLE;
        else
            state <= next_state;
    end

    //---------------------------------------
    // counter
    //---------------------------------------
    always @(posedge clk or posedge reset) begin
        if (reset)
            counter <= 0;
        else begin
            case(state)

                LOAD_IN:
                    counter <= counter + 1;

                SHIFT_OUT:
                    counter <= counter + 1;

                default:
                    counter <= 0;

            endcase
        end
    end

    //---------------------------------------
    // next-state logic
    //---------------------------------------
    always @(*) begin

        case(state)

            IDLE:
                if(start)
                    next_state = LOAD_IN;
                else
                    next_state = IDLE;

            LOAD_IN:
                if(counter == 5'd15)
                    next_state = CLEAR_ACC;
                else
                    next_state = LOAD_IN;

            CLEAR_ACC:
                next_state = MUL0_ACC;

            MUL0_ACC:
                next_state = MUL1_ACC;

            MUL1_ACC:
                next_state = MUL2_ACC;

            MUL2_ACC:
                next_state = MUL3_ACC;

            MUL3_ACC:
                next_state = LOAD_P2S;

            LOAD_P2S:
                next_state = SHIFT_OUT;

            SHIFT_OUT:
                if(counter == 5'd15)
                    next_state = DONE_ST;
                else
                    next_state = SHIFT_OUT;

            DONE_ST:
                next_state = IDLE;

            default:
                next_state = IDLE;

        endcase

    end

    //---------------------------------------
    // output logic
    //---------------------------------------
    always @(*) begin

        // default
        s2p_shift_en = 0;
        clear_acc    = 0;
        load_acc     = 0;
        p2s_load     = 0;
        p2s_shift_en = 0;
        done         = 0;

        shift_sel = 2'b00;
        a_sel     = 0;
        b_sel     = 0;

        case(state)

            LOAD_IN:
                s2p_shift_en = 1;

            CLEAR_ACC:
                clear_acc = 1;

            MUL0_ACC: begin
                load_acc = 1;
                shift_sel = 2'b00;
                a_sel = 0;
                b_sel = 0;
            end

            MUL1_ACC: begin
                load_acc = 1;
                shift_sel = 2'b01;
                a_sel = 1;
                b_sel = 0;
            end

            MUL2_ACC: begin
                load_acc = 1;
                shift_sel = 2'b01;
                a_sel = 0;
                b_sel = 1;
            end

            MUL3_ACC: begin
                load_acc = 1;
                shift_sel = 2'b10;
                a_sel = 1;
                b_sel = 1;
            end

            LOAD_P2S:
                p2s_load = 1;

            SHIFT_OUT:
                p2s_shift_en = 1;

            DONE_ST:
                done = 1;

        endcase

    end

endmodule
