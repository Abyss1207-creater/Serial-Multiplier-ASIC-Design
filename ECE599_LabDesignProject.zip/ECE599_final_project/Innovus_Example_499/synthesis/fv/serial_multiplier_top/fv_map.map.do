
//input ports
add mapped point clk clk -type PI PI
add mapped point reset reset -type PI PI
add mapped point start start -type PI PI
add mapped point in in -type PI PI

//output ports
add mapped point out out -type PO PO
add mapped point done done -type PO PO

//inout ports




//Sequential Pins
add mapped point u_fsm/state[1]/q u_fsm/state_reg[1]/Q -type DFF DFF
add mapped point u_fsm/counter[3]/q u_fsm/counter_reg[3]/Q -type DFF DFF
add mapped point u_fsm/state[0]/q u_fsm/state_reg[0]/Q -type DFF DFF
add mapped point u_fsm/state[2]/q u_fsm/state_reg[2]/Q -type DFF DFF
add mapped point u_fsm/counter[2]/q u_fsm/counter_reg[2]/Q -type DFF DFF
add mapped point u_fsm/counter[1]/q u_fsm/counter_reg[1]/Q -type DFF DFF
add mapped point u_fsm/counter[0]/q u_fsm/counter_reg[0]/Q -type DFF DFF
add mapped point u_p2s/shift_reg[1]/q u_p2s/shift_reg_reg[1]/Q -type DFF DFF
add mapped point u_p2s/shift_reg[2]/q u_p2s/shift_reg_reg[2]/Q -type DFF DFF
add mapped point u_p2s/shift_reg[7]/q u_p2s/shift_reg_reg[7]/Q -type DFF DFF
add mapped point u_p2s/shift_reg[5]/q u_p2s/shift_reg_reg[5]/Q -type DFF DFF
add mapped point u_p2s/shift_reg[4]/q u_p2s/shift_reg_reg[4]/Q -type DFF DFF
add mapped point u_p2s/shift_reg[3]/q u_p2s/shift_reg_reg[3]/Q -type DFF DFF
add mapped point u_p2s/shift_reg[6]/q u_p2s/shift_reg_reg[6]/Q -type DFF DFF
add mapped point u_p2s/shift_reg[0]/q u_p2s/shift_reg_reg[0]/Q -type DFF DFF
add mapped point u_s2p/shift_reg[4]/q u_s2p/shift_reg_reg[4]/Q -type DFF DFF
add mapped point u_s2p/shift_reg[1]/q u_s2p/shift_reg_reg[1]/Q -type DFF DFF
add mapped point u_s2p/shift_reg[0]/q u_s2p/shift_reg_reg[0]/Q -type DFF DFF
add mapped point u_s2p/shift_reg[5]/q u_s2p/shift_reg_reg[5]/Q -type DFF DFF
add mapped point u_s2p/shift_reg[7]/q u_s2p/shift_reg_reg[7]/Q -type DFF DFF
add mapped point u_s2p/shift_reg[2]/q u_s2p/shift_reg_reg[2]/Q -type DFF DFF
add mapped point u_s2p/shift_reg[6]/q u_s2p/shift_reg_reg[6]/Q -type DFF DFF
add mapped point u_s2p/shift_reg[3]/q u_s2p/shift_reg_reg[3]/Q -type DFF DFF



//Black Boxes



//Empty Modules as Blackboxes
