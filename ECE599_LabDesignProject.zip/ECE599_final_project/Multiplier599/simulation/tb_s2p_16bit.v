`timescale 1ns/1ps

module tb_s2p_16bit;

    reg        clk;
    reg        reset;
    reg        shift_en;
    reg        in;
    wire [7:0] A;
    wire [7:0] B;

    s2p_16bit uut (
        .clk(clk),
        .reset(reset),
        .shift_en(shift_en),
        .in(in),
        .A(A),
        .B(B)
    );

    // 10ns clock period
    always #5 clk = ~clk;

    initial begin
        clk      = 1'b0;
        reset    = 1'b1;
        shift_en = 1'b0;
        in       = 1'b0;

        // reset
        #12;
        reset    = 1'b0;
        shift_en = 1'b1;

        // Send A = 10110011
        in = 1'b1; #10;  // A7
        in = 1'b0; #10;  // A6
        in = 1'b1; #10;  // A5
        in = 1'b1; #10;  // A4
        in = 1'b0; #10;  // A3
        in = 1'b0; #10;  // A2
        in = 1'b1; #10;  // A1
        in = 1'b1; #10;  // A0

        // Send B = 01010101
        in = 1'b0; #10;  // B7
        in = 1'b1; #10;  // B6
        in = 1'b0; #10;  // B5
        in = 1'b1; #10;  // B4
        in = 1'b0; #10;  // B3
        in = 1'b1; #10;  // B2
        in = 1'b0; #10;  // B1
        in = 1'b1; #10;  // B0

        shift_en = 1'b0;
        #10;

        $display("A = %b (expected 10110011)", A);
        $display("B = %b (expected 01010101)", B);

        if (A == 8'b10110011 && B == 8'b01010101)
            $display("PASS: s2p_16bit works correctly.");
        else
            $display("FAIL: s2p_16bit output mismatch.");

        #10;
        $finish;
    end

endmodule
