`timescale 1ns/1ps

module controller_fsm(

    input clk,
    input reset,
    input start,

    output reg s2p_shift_en,
    output reg p2s_load,
    output reg p2s_shift_en,
    output reg done
);

    // FSM states
    localparam IDLE      = 3'd0;
    localparam LOAD_IN   = 3'd1;
    localparam LOAD_P2S  = 3'd2;
    localparam SHIFT_OUT = 3'd3;
    localparam DONE_ST   = 3'd4;

    reg [2:0] state, next_state;
    reg [3:0] counter;

    //---------------------------------------
    // State register
    //---------------------------------------
    always @(posedge clk or posedge reset) begin
        if (reset)
            state <= IDLE;
        else
            state <= next_state;
    end

    //---------------------------------------
    // Counter
    //---------------------------------------
    always @(posedge clk or posedge reset) begin
        if (reset)
            counter <= 0;
        else begin

            case(state)

                LOAD_IN:
                    counter <= counter + 1;

                SHIFT_OUT:
                    counter <= counter + 1;

                default:
                    counter <= 0;

            endcase

        end
    end

    //---------------------------------------
    // Next-state logic
    //---------------------------------------
    always @(*) begin

        case(state)

            IDLE:
                if(start)
                    next_state = LOAD_IN;
                else
                    next_state = IDLE;

            LOAD_IN:
                if(counter == 4'd7)
                    next_state = LOAD_P2S;
                else
                    next_state = LOAD_IN;

            LOAD_P2S:
                next_state = SHIFT_OUT;

            SHIFT_OUT:
                if(counter == 4'd7)
                    next_state = DONE_ST;
                else
                    next_state = SHIFT_OUT;

            DONE_ST:
                next_state = IDLE;

            default:
                next_state = IDLE;

        endcase

    end

    //---------------------------------------
    // Output logic (Moore FSM)
    //---------------------------------------
    always @(*) begin

        // default outputs
        s2p_shift_en = 0;
        p2s_load     = 0;
        p2s_shift_en = 0;
        done         = 0;

        case(state)

            LOAD_IN:
                s2p_shift_en = 1;

            LOAD_P2S:
                p2s_load = 1;

            SHIFT_OUT:
                p2s_shift_en = 1;

            DONE_ST:
                done = 1;

        endcase

    end

endmodule
